#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <locale.h>

/// Nodo para manipular as pilhas
struct Node
{
    int coluna;
    int linha;
    struct Node* prox;
};
typedef struct Node Node;

void arrumar_lab(char ***labirinto, int *linha, int *coluna);
void inserir_rato(char ***labirinto, Node **p, int *pos_rato_linha, int *pos_rato_coluna,int *linha, int *coluna);
void exibir_lab(char ***labirinto, int *linha, int *coluna);
void leitura_lab(int *linha, int *coluna, char ***labirinto, int *qnt);
int verificar_lab(char ***labirinto, int *linha, int *coluna, int *linha_s, int *coluna_s;);
void menu();
void liberar_rato(char ***labirinto, Node **caminho, int linha_rato, int coluna_rato, int *linha, int *coluna, int *linha_s, int *coluna_s, int *qnt);
void push(Node **p, int linha, int coluna);
void print_stack(Node *p);
Node* pop(Node **p, char ***labirinto, int *qnt, int *linha, int *coluna);

int main() {
    setlocale(LC_ALL,"Portuguese");
    int i;
    int linha = 0;
    int coluna = 0;
    int pos_rato_linha = 0;
    int pos_rato_coluna = 0;
    char **labirinto;
    int *linha_s = 0;
    int *coluna_s = 0;
    int *qnt = 0;

    Node *headPilha = NULL;

    menu();
    leitura_lab(&linha, &coluna, &labirinto, &qnt);
    verificar_lab(&labirinto, &linha, &coluna, &linha_s, &coluna_s);
    exibir_lab(&labirinto, &linha, &coluna);
    inserir_rato(&labirinto, &headPilha, &pos_rato_linha, &pos_rato_coluna, &linha, &coluna);
    exibir_lab(&labirinto, &linha, &coluna);
    liberar_rato(&labirinto, &headPilha, pos_rato_linha, pos_rato_coluna, &linha, &coluna, &linha_s, &coluna_s, &qnt);
    print_stack(headPilha);
    arrumar_lab(&labirinto, &linha, &coluna);
    exibir_lab(&labirinto, &linha, &coluna);
    free(labirinto);

    return 0;
}


void menu (){
    printf("=========================================================\n");
    printf("=================== Labirinto do Rato ===================\n");
    printf("=========================================================\n");
    printf("\n");
    printf("Digite o nome do arquivo: ");
}
/// Armazena o labirinto do txt para matrizes
void leitura_lab(int *linha, int *coluna, char ***labirinto, int *qnt) {
    char nome_arquivo[100];
    scanf("%s", nome_arquivo);

    printf("\n");

    FILE *arq_lab = fopen(nome_arquivo, "r");

    if (arq_lab == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        exit(1);
    }

    fscanf(arq_lab, "%d %d", linha, coluna);
    printf("Linha: %d e Coluna: %d \n\n", *linha, *coluna);


    *labirinto = (char **)malloc(*linha * sizeof(char *));
    for (int i = 0; i < *linha; i++) {
        (*labirinto)[i] = (char *)malloc(*coluna * sizeof(char));
    }

    for (int i = 0; i < *linha; i++) {
        for (int j = 0; j < *coluna; j++) {
            fscanf(arq_lab, " %c", &(*labirinto)[i][j]);
            if((*labirinto)[i][j] == '0'){
                *qnt += 1;
            }
        }
    }

    fclose(arq_lab);
}

int verificar_lab(char ***labirinto, int *linha, int *coluna, int *linha_s, int *coluna_s){
    int cont_de_saida=0, i, j;
    int horizontal = 0, vertical = 0;
    /// Verifica se as linhas da extremidade do labirinto s�o paredes (X) ou saida (S)
    for(i = 0; i < *linha; i = i+(*linha-1)){
        for(j = 0; j < *coluna; j++){
            if((*labirinto) [i][j] == 'X' || (*labirinto) [i][j] == 'S'){
                horizontal++;
              if((*labirinto)[i][j]== 'S'){
                    cont_de_saida++;
                    *linha_s = i;
                    *coluna_s = j;
                }
            }
        }
    }
    /// Verifica se as colunas da extremidade do labirinto s�o paredes (X) ou saida (S)
    for(i=1; i<*linha - 1; i++){
        if(((*labirinto) [i][0] == 'X' || (*labirinto) [i][0] == 'S') || ((*labirinto) [i][*coluna-1] == 'X' || (*labirinto) [i][*coluna-1] == 'S')){
            vertical++;
           if ((*labirinto)[i][0]== 'S' || (*labirinto) [i][*coluna-1] == 'S'){
                cont_de_saida++;
            }
        }
    }
    /// Se todos caracteres forem paredes ou saida, o labirinto � valido
    if(horizontal == (*coluna * 2) && vertical == (*linha - 2) && cont_de_saida > 0){
        printf("Labirinto valido!!\n\n");
    }
    /// Caso contrario encerra o programa
    else {
        printf("Labirinto invalido!!\n\n");
        exit(1);
    }
}
/// Printa o labirinto inteiro
void exibir_lab(char ***labirinto, int *linha, int *coluna){
    int i,j;
    printf("Labirinto:\n\n");
    for (i = 0; i < *linha; i++) {
        for (j = 0; j < *coluna; j++) {
            printf("%c", (*labirinto)[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
/// Pede a posi��o do rato em linha e coluna, em seguida verifica se a posi��o � v�lida
void inserir_rato(char ***labirinto, Node **p, int *pos_rato_linha, int *pos_rato_coluna, int *linha, int *coluna){
    printf("Insira a posi��o do rato (linha/coluna): ");
    scanf("%d %d", pos_rato_linha, pos_rato_coluna);
    printf("\n");
    if((*labirinto) [*pos_rato_linha][*pos_rato_coluna] == 'X' || (*labirinto) [*pos_rato_linha][*pos_rato_coluna] == 'S' || *pos_rato_coluna >= *coluna || *pos_rato_coluna < 0 || *pos_rato_linha >= *linha || *pos_rato_linha < 0){
        printf("Posicaoo invalida\n");
        inserir_rato(labirinto, p, pos_rato_linha, pos_rato_coluna, linha, coluna);
    }
    else {
        (*labirinto) [*pos_rato_linha] [*pos_rato_coluna] = 'R';
        push(p, *pos_rato_linha, *pos_rato_coluna);
    }
}
/// Libera o rato a andar pelo labirinto
void liberar_rato(char ***labirinto, Node **caminho, int linha_rato, int coluna_rato, int *linha, int *coluna, int *linha_s, int *coluna_s, int *qnt){
    int podeAndar = 1;
    int lRato = linha_rato;
    int cRato = coluna_rato;

    /// Faz ele testar todos os caminhos poss�veis para cada bloco que ele anda
    while(podeAndar){
        if(
            !((*labirinto)[lRato][cRato + 1] == '0' || (*labirinto)[lRato][cRato + 1] == 'S') &&
            !((*labirinto)[lRato][cRato - 1] == '0' || (*labirinto)[lRato][cRato - 1] == 'S') &&
            !((*labirinto)[lRato + 1][cRato] == '0' || (*labirinto)[lRato + 1][cRato] == 'S') &&
            !((*labirinto)[lRato - 1][cRato] == '0' || (*labirinto)[lRato - 1][cRato] == 'S')
        ){
            Node *n = pop(caminho, labirinto, qnt, linha, coluna);
            lRato = (*caminho)->linha;
            cRato = (*caminho)->coluna;
            continue;
        }

        int mov = (rand() % 4) + 1;

        switch(mov){
            /// Faz ele andar para baixo
            case 1:
                if((*labirinto)[lRato + 1][cRato] == '0' || (*labirinto)[lRato + 1][cRato] == 'S'){ // Baixo
                    if((*labirinto)[lRato + 1][cRato] == 'S'){
                        push(caminho, lRato + 1, cRato);
                        return;
                    }
                    (*labirinto)[lRato + 1][cRato] = 'C';
                    // printf("Andando para Baixo\n");
                    lRato = lRato + 1;
                    push(caminho, lRato, cRato);
                    continue;
                }
                break;
            /// Faz ele andar para Cima
            case 2:
                if((*labirinto)[lRato - 1][cRato] == '0' || (*labirinto)[lRato - 1][cRato] == 'S'){ // Cima
                    if((*labirinto)[lRato - 1][cRato] == 'S'){
                        push(caminho, lRato - 1, cRato);
                        return;
                    }
                    (*labirinto)[lRato - 1][cRato] = 'C';
                    // printf("Andando para Cima\n");
                    lRato = lRato - 1;
                    push(caminho, lRato, cRato);
                    continue;
                }
                break;
            /// Faz ele andar para direita
            case 3:
                if((*labirinto)[lRato][cRato + 1] == '0' || (*labirinto)[lRato][cRato + 1] == 'S'){ // Direita
                    if((*labirinto)[lRato][cRato + 1] == 'S'){
                        push(caminho, lRato, cRato + 1);
                        return;
                    }
                    (*labirinto)[lRato][cRato + 1] = 'C';
                    // printf("Andando para Direita\n");
                    cRato = cRato + 1;
                    push(caminho, lRato, cRato);
                    continue;
                }
                break;
            /// Faz ele andar para esquerda
            case 4:
                if((*labirinto)[lRato][cRato - 1] == '0' || (*labirinto)[lRato][cRato - 1] == 'S'){ // Esquerda
                    if((*labirinto)[lRato][cRato - 1] == 'S'){
                        push(caminho, lRato, cRato - 1);
                        return;
                    }
                    (*labirinto)[lRato][cRato - 1] = 'C';
                    // printf("Andando para Esquerda\n");
                    cRato = cRato - 1;
                    push(caminho, lRato, cRato);
                    continue;
                }
                break;
            default:
                break;
        }
    }
}
/// Adiciona um elemento na pilha
void push(Node **p, int linha, int coluna){
    Node *novoTopo = malloc(sizeof(Node));
    novoTopo->coluna = coluna;
    novoTopo->linha = linha;
    novoTopo->prox = *p;

    // printf("%x ->  %x (%x)\n", novoTopo, novoTopo->prox, p);
    *p = novoTopo;
    // printf("new head: %d %d\n", (*p)->linha, (*p)->coluna);
}
/// Printa a pilha
void print_stack(Node *p){
    Node *nav = p;
    printf("Caminho mais r�pido: \n");
    while(nav){
        printf("linha: %d coluna: %d\n", nav->linha, nav->coluna);
        nav = nav->prox;
    }
    printf("\n");
}
/// Tira um elemento da pilha
Node* pop(Node **p, char ***labirinto, int *qnt, int *linha, int *coluna){
    if(!*p) return NULL;

    Node* n = malloc(sizeof(Node));
    n->linha = (*p)->linha;
    n->coluna = (*p)->coluna;

    (*labirinto)[n->linha][n->coluna] = '#';
    *qnt = *qnt - 1;

    (*p) = (*p)->prox;

    if(*qnt == 0){
        printf("Labirinto n�o tem sa�da\n\n");
        exibir_lab(labirinto, linha, coluna);
        exit(1);
    }

    return n;
}
/// Arruma o labirinto atualizando a posi��o do rato
void arrumar_lab(char ***labirinto, int *linha, int *coluna){
     int i,j, aux_linha = -1, aux_coluna = -1;
    printf("Labirinto:\n\n");
    for (i = 0; i < *linha; i++) {
        for (j = 0; j < *coluna; j++) {
            if((*labirinto)[i][j] == 'S'){
                (*labirinto)[i][j] = 'R';
                aux_linha = i;
                aux_coluna = j;
            }
            if((*labirinto)[i][j] == 'R' &&  i != aux_linha && j != aux_coluna){
                (*labirinto)[i][j] = 'C';
            }
        }
    }

}
